 //实现回到顶部
 var backUp=document.querySelector('.backUp');
 var timerId=null
 backUp.onclick=function(){
     timerId=setInterval(function(){
         document.documentElement.scrollTop-=10
         if(document.documentElement.scrollTop==0){
             clearInterval(timerId)
         }
         window.onwheel=function(){
             clearInterval(timerId)
         }
     },10);
 }

 window.onload = function(event){
    if(document.documentElement.scrollTop < 300){
        backUp.classList.add('current')
    }else{
        backUp.classList.remove('current')
    }
 }

 document.addEventListener('scroll',function(){
    if(document.documentElement.scrollTop < 300){
        backUp.classList.add('current')
    }
    else{
        backUp.classList.remove('current')
    }
 },false)

 //=========================实现side点击的页面的跳转============
 var side_trial = document.querySelector('.side_trial')
 var side_smile = document.querySelector('.side_smile')
 side_trial.addEventListener('click',function(event){
        window.open("https://web.paradisecloud.cn/");
 },false)
 side_smile.addEventListener('click',function(event){
        location.href = 'http://47.106.142.250/Meeting/page/m_gonsijianjie.html'
 },false)
 
    //移入微信展示微信图标

var side_weixin_box = document.querySelector('.side_weixin_box')
var side_weixin = document.querySelector('.side_weixin')
side_weixin_box.addEventListener('mousemove',function(event){
    side_weixin.classList.add('side_weixin_02')
})
side_weixin_box.addEventListener('mouseout',function(event){
    side_weixin.classList.remove('side_weixin_02')
})


//点击join加入会议
var join =document.querySelector('.join')
join.addEventListener('click',function(event){
    window.open('https://web.paradisecloud.cn/#')
},false)
