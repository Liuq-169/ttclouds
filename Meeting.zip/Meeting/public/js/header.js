var header = document.querySelector('.header');
var social = document.querySelector('.social')
var logo = document.querySelector('#logo');
var list_son = document.querySelectorAll('.list_son>li')
var m_kaifazhe = document.querySelector('#m_kaifazhe')
var m_bangzhuzhonxin = document.querySelector('#m_bangzhuzhonxin')
var m_xiazai = document.querySelector('#m_xiazai')
var menu_joinMeeting = document.querySelector('#menu_joinMeeting')
var menu_register = document.querySelector('#menu_register')
// var menu_login = document.querySelector('.menu_login')

// 判断滑动条位置进行header样式的设置
// document.addEventListener('scroll', function () {
//     if (document.documentElement.scrollTop > 300) {
//         header.classList.add('header_fixed')
//         social.classList.add('social_fixed')
//         // logo.src = 'http://www.527meeting.com/wp-content/uploads/2018/11/logo01.png'        
//     }
//     else {
//         header.classList.remove('header_fixed')
//         social.classList.remove('social_fixed')
//         // logo.src = 'http://www.527meeting.com/wp-content/uploads/2018/11/logo02.png'
//     }
// }, false)

//设置用户点击二级菜单并发生跳转
for (var i = 0; i < list_son.length; i++) {
    list_son[i].addEventListener('click', function (event) {
        console.log(2);
        
        sessionStorage.setItem(`${event.target.id}`, `${event.target.id}`)
        // let a = location.href.split('/')
        // if (a[a.length - 1] == 'index.html' || a[a.length - 1]=='') {
        //     location.href = `page/${event.target.id}.html`
        // } else {
            location.href = `../page/${event.target.id}.html`
        // }
    }, false)
}

//设置用户点击一级菜单并发生跳转

zuixin.addEventListener('click', function (event) {
    sessionStorage.setItem(`${event.target.id}`, `${event.target.id}`)
    // let a = location.href.split('/')
    // if (a[a.length - 1] == 'index.html' || a[a.length - 1]=='') {
    //     location.href = `page/Development.html`
    // } else {
        location.href = `../page/zuixin.html`
    // }
}, false)

m_kaifazhe.addEventListener('click', function (event) {
    sessionStorage.setItem(`${event.target.id}`, `${event.target.id}`)
    // let a = location.href.split('/')
    // if (a[a.length - 1] == 'index.html' || a[a.length - 1]=='') {
    //     location.href = `page/Development.html`
    // } else {
        location.href = `../page/Development.html`
    // }
}, false)

m_bangzhuzhonxin.addEventListener('click', function (event) {
    sessionStorage.setItem(`${event.target.id}`, `${event.target.id}`)
        location.href = `../page/m_bangzhuzhonxin.html`
}, false)

m_xiazai.addEventListener('click', function (event) {
    // let a = location.href.split('/')
    sessionStorage.setItem(`${event.target.id}`, `${event.target.id}`)
    // if (a[a.length - 1] == 'index.html' || a[a.length - 1]=='') {
    //     location.href = `page/download.html`
    // } else {
        location.href = `../page/download.html`
    // }
}, false)


// menu_joinMeeting.addEventListener('click',function(event){
//     sessionStorage.setItem(`${event.target.id}`,`${event.target.id}`)
//     location.href = `../page/login.html`
// },false)

// menu_register.addEventListener('click',function(event){
//     sessionStorage.setItem(`${event.target.id}`,`${event.target.id}`)
//     location.href = `../page/login.html`
// },false)

// menu_login.addEventListener('click', function (event) {
//     // let a = location.href.split('/')
//     sessionStorage.setItem(`${event.target.id}`, `${event.target.id}`)
//     // if (a[a.length - 1] == 'index.html' || a[a.length - 1]=='') {
//     //     location.href = `page/login.html`
//     // } else {
//         location.href = `../page/login.html`
//     // }
// }, false)






