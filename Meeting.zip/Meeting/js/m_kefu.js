var currentNav = document.querySelector('#m_kefu')
window.onload=function(){
    if(sessionStorage.m_kefu){
        currentNav.classList.add('navCurrent')
    }
    if(sessionStorage.userId){
        let userInfo = JSON.parse(sessionStorage.userInfo)
        document.querySelector('.menu_login').innerHTML = userInfo.nickname
    }  
}
var programme_nav = document.querySelectorAll('.programme_nav>li')
var programme_img = document.querySelectorAll('.programme_img>li')
var navLen = programme_nav.length 
for(var i =0 ;i<navLen;i++){
    programme_nav[i].addEventListener('click',function(event){
        let index = Number(this.dataset.index) 
        for(var i = 0; i<navLen ; i++){
            programme_nav[i].classList.remove('programme_nav_current')
            programme_img[i].classList.remove('programme_img_current')
        }
        event.target.classList.add('programme_nav_current')
        programme_img[index].classList.add('programme_img_current')
    },false)
}