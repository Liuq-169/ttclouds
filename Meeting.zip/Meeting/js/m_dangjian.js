var currentNav = document.querySelector('#m_dangjian')
window.onload=function(){
    if(sessionStorage.m_dangjian){
        currentNav.classList.add('navCurrent')
    }
    if(sessionStorage.userId){
        let userInfo = JSON.parse(sessionStorage.userInfo)
        document.querySelector('.menu_login').innerHTML = userInfo.nickname
    }  
}
