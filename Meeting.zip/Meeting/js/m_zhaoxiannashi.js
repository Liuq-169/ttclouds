var currentNav = document.querySelector('#m_zhaoxiannashi')
window.onload=function(){
    if(sessionStorage.m_zhaoxiannashi){
        currentNav.classList.add('navCurrent')
    }
    if(sessionStorage.userId){
        let userInfo = JSON.parse(sessionStorage.userInfo)
        document.querySelector('.menu_login').innerHTML = userInfo.nickname
    }  
}