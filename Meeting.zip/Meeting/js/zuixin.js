var currentNav = document.querySelector('#zuixin')
window.onload = function () {
    if (sessionStorage.zuixin) {
        currentNav.classList.add('navCurrent')
    }
    if(sessionStorage.userId){
        let userInfo = JSON.parse(sessionStorage.userInfo)
        document.querySelector('.menu_login').innerHTML = userInfo.nickname
    }   
}

var content_nav = document.querySelectorAll('.content_nav>li')
var content_txt = document.querySelectorAll('.content_txt>li')
var hot = document.querySelectorAll('.hot')

for(var i = 0;i<content_nav.length;i++){
    
    
    content_nav[i].addEventListener('click',function(event){
        let index = this.dataset.index
        for(var i = 0;i<content_nav.length;i++){
            content_nav[i].classList.remove('nav_current')
            content_txt[i].classList.remove('txt_current')
            hot[i].classList.remove('spanCurrent')
        }
        event.target.classList.add('nav_current')
        content_txt[index].classList.add('txt_current')
        hot[index].classList.add('spanCurrent')
    },false)
}