var currentNav = document.querySelector('#m_kaifazhe')
window.onload = function () {
    if (sessionStorage.m_kaifazhe) {
        currentNav.classList.add('navCurrent')
    }
    if(sessionStorage.userId){
        let userInfo = JSON.parse(sessionStorage.userInfo)
        document.querySelector('.menu_login').innerHTML = userInfo.nickname
    }   
}
var navList_p = document.querySelectorAll('.navList>li>p')
var navList_div = document.querySelectorAll('.navList>li>div')
var classOne_p = document.querySelectorAll('.classOne>p')
var content_txt = document.querySelector('.content_txt')
// 点击 title 展开
for (let i = 0; i < navList_p.length; i++) {
    navList_p[i].addEventListener('click', function (event) {
        var targetParent = this.parentNode;
        var aDiv = targetParent.getElementsByTagName('div')
        var aLi = document.querySelectorAll(".navList>li")
        var aDivLen = aDiv.length
        if (parseInt(targetParent.style.height) == 50 || targetParent.style.height == '') {
            targetParent.style.height = 50 * (aDivLen + 1) + 'px'
        }
        else {
            targetParent.style.height = '50px'
        }
    })
}
// 点击对应的 li 样式赋予及右边相关内容的展示
function handleCurrCode(obj){
    let dataCode = obj.dataset.code
    let currCode = document.querySelector('.'+dataCode);
    let currCode_sibling = currCode.parentNode.children
    for(let y = 0; y< currCode_sibling.length ; y++){
        currCode_sibling[y].classList.remove('contentCurrent')
    }
    currCode.classList.add('contentCurrent')
    let currCodeH = currCode.clientHeight + 58
    content_txt.style.height = currCodeH + 'px'
}
for(let i = 0 ; i<navList_div.length;i++){
    navList_div[i].addEventListener('click',function(event){
        for(let k =0 ;k < classOne_p.length;k++){
            classOne_p[k].classList.remove('main_navCurrent02')
        }
        for(let j =0 ; j< navList_div.length;j++){
            navList_div[j].classList.remove('main_navCurrent')
        }
        event.target.classList.add('main_navCurrent')
        handleCurrCode(this)
    },false)
}
for(let i =0 ; i<classOne_p.length;i++){
    classOne_p[i].addEventListener('click',function(event){
        for(let k =0 ;k < classOne_p.length;k++){
            classOne_p[k].classList.remove('main_navCurrent02')
        }
        for(let j =0 ; j< navList_div.length;j++){
            navList_div[j].classList.remove('main_navCurrent')
        }
        event.target.classList.add('main_navCurrent02')
        handleCurrCode(this)
    },false)
}