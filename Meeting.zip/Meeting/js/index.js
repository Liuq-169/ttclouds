var main_lunbo = document.querySelector('.main_lunbo')
var lunboList = document.querySelector('.lunboList')
var left = document.querySelector('.left')
var right = document.querySelector('.right')
var icon_li = document.querySelectorAll('.icon_box>li')
var platform_list = document.querySelectorAll('.platform_list>li')
var about_list = document.querySelectorAll('.about_list>li')
var sceneTxt = document.querySelectorAll('.sceneTxt>li')
var index = 0

window.onload = function () {
    window.onscroll();
    if (sessionStorage.userId) {
        let userInfo = JSON.parse(sessionStorage.userInfo)
        document.querySelector('.menu_login').innerHTML = userInfo.nickname
    }
}


// ==================通过判断滚动距离来展示加载样式
// 添加样式 的函数 
function addClass(obj){
    obj.classList.add('animation')
}

// 通过“offsetTop”来连续获取节点到文档顶部的距离并更新，直到节点再没有父级为止
function getTop(obj) {
    var h = 0;
    while (obj) {
        h += obj.offsetTop+20;
        obj = obj.offsetParent;
    }
    return h;
}
// 滚动实时计算所到区域计算“节点到顶部距离”与“滚动条滚动距离”的大小，当“滚动条滚动距离”大于“节点到顶部距离”时开始创建一个img（（1）的函数）
window.onscroll = function () {
    var t = document.documentElement.clientHeight + (document.body.scrollTop || document.documentElement.scrollTop);
    for (var i = 0; i < platform_list.length; i++) {
        if (getTop(platform_list[i]) < t) {
            setTimeout('addClass(platform_list[' + i + '])', 500)
        }
    }
    for (var i = 0; i < about_list.length; i++) {
        if (getTop(about_list[i]) < t) {
            setTimeout('addClass(about_list[' + i + '])', 500)
        }
    }
    for (var i = 0; i < sceneTxt.length; i++) {
        if (getTop(sceneTxt[i]) < t) {
            setTimeout('addClass(sceneTxt[' + i + '])', 500)
        }
    }
}


//轮播图

// var timer = setInterval(function(){
//     index++;
//     if (index > 2) {
//         index = 0;
//         lunboList.style.transition = 'all 0s ease-in-out';
//     } else {
//         lunboList.style.transition = 'all 0.5s ease-in-out';
//     }
//     lunboList.style.left = - main_lunbo.clientWidth * index + 'px'

//     for (var i = 0; i < icon_li.length; i++) {
//         icon_li[i].classList.remove('icon_currten')
//     }
//     icon_li[index].classList.add('icon_currten')
// },4000)

// left.addEventListener('click', function (event) {
//     // clearInterval(timer)
//     index--;
//     if (index < 0) {
//         index = 2;
//         lunboList.style.transition = 'all 0s ease-in-out';
//     } else {
//         lunboList.style.transition = 'all 0.5s ease-in-out';
//     }

//     lunboList.style.left = -main_lunbo.clientWidth * index + 'px'

//     for (var i = 0; i < icon_li.length; i++) {
//         icon_li[i].classList.remove('icon_currten')
//     }
//     icon_li[index].classList.add('icon_currten')
// }, false)

// right.addEventListener('click', function (event) {
//     // clearInterval(timer)
//     index++;
//     if (index > 2) {
//         index = 0;
//         lunboList.style.transition = 'all 0s ease-in-out';
//     } else {
//         lunboList.style.transition = 'all 0.5s ease-in-out';
//     }
//     lunboList.style.left = - main_lunbo.clientWidth * index + 'px'

//     for (var i = 0; i < icon_li.length; i++) {
//         icon_li[i].classList.remove('icon_currten')
//     }
//     icon_li[index].classList.add('icon_currten')
// }, false)

//云产品点击跳转
var platform_list_gyyun = document.querySelector('.platform_list_gyyun')
var platform_list_zsyun = document.querySelector('.platform_list_zsyun')
var platform_list_znzduan = document.querySelector('.platform_list_znzduan')
platform_list_gyyun.addEventListener('click',function(event){
    location.href = './page/m_gonyouyun.html'
})
platform_list_zsyun.addEventListener('click',function(event){
    location.href = './page/m_zhuanshuyun.html'
})
platform_list_znzduan.addEventListener('click',function(event){
    location.href = './page/m_zhinengzhonduan.html'
})


// 解决方案
var sceneNav = document.querySelectorAll('.sceneNav>li')
var sceneTxt = document.querySelectorAll('.sceneTxt>li')
var main_scene = document.querySelector('.main_scene')

for (var i = 0; i < sceneNav.length; i++) {
    sceneNav[i].addEventListener('click', function (event) {
        let index = Number(this.dataset.sceneindex)
        switch (index) {
            case 0:
                main_scene.style.backgroundImage = "url('https://www.zijingcloud.com/static/solute/bg_home_goverment.png')";
                
                break;
            case 1:
                main_scene.style.backgroundImage = "url('https://www.zijingcloud.com/static/solute/bg_home_party.png')";
                break;
            case 2:
                main_scene.style.backgroundImage = "url('https://www.zijingcloud.com/static/solute/bg_home_financial.png')";
                break;
            case 3:
                main_scene.style.backgroundImage = "url('https://www.zijingcloud.com/static/solute/bg_home_education.png')";
                break;
            case 4:
                main_scene.style.backgroundImage = "url('https://www.zijingcloud.com/static/solute/bg_home_medical.png')";
        }
        for (var i = 0; i < sceneNav.length; i++) {
            sceneNav[i].classList.remove('sceneNavCurrent')
            sceneTxt[i].classList.remove('sceneTxtCurrent')
        }
        sceneNav[index].classList.add('sceneNavCurrent')
        sceneTxt[index].classList.add('sceneTxtCurrent')
    }, false)
}