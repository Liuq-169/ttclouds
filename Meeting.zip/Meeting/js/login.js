/*  页面登录 注册 的切换 */ 

var myregister =$('#myregister')
var mylogin = $('#mylogin')
var login = $('.login')
var register = $('.register')

mylogin.on('click',function(){
	login.fadeIn(2000);
	register.fadeOut(200);
})

myregister.on('click',function(){
	register.fadeIn(2000);
	login.fadeOut(200);
})


// ajax注册

$('.myregister').on('click',function(){
	$.ajax({
		url:'http://118.24.25.7/chat_api/interface/reg.php',
		type:'post',
		data:{
			username:$('#newuser').val(),
			password:$('#newpassword').val(),
			nickname:$('#newemail').val()
		},
		success(data){
			if(data.code==0){
				// console.log(data)
				$('.show').html('注册成功!').show(1000).hide(2000)
			}else if(data.code==1){
				$('.show').html('用户名、密码、昵称某项为空').show(1000).hide(2000)
			}else if(data.code==2){
				$('.show').html('用户名格式不符合规范').show(1000).hide(2000)
			}else if(data.code==3){
				$('.show').html('密码格式不符合规范').show(1000).hide(2000)
			}else if(data.code==4){
				$('.show').html('注册失败，可能的原因包括用户名重复等').show(200).hide(2000)
			}
		},
		error(err){
			console.log(err.statusText);
		}
	})
	
})


//ajax 登录：
var userInfo=null;
$('.mylogin').on('click',function(){
	
	$.ajax({
		type: 'POST',
		url: 'http://118.24.25.7/chat_api/interface/login.php',
		data: {
			username:$('#user').val(),
			password:$('#password').val()
		},
		success(data) {
			if (data.code == 0) {
				$('.show').html('登录成功!').show(200).hide(10000)
				setTimeout(function(){
					window.location.href='../index.html'
				},2000)
				sessionStorage.sign_str=data.data.sign_str;
				sessionStorage.userId=data.data.id;
				sessionStorage.userInfo= JSON.stringify(data.data);
			}
			else{
				$('.show').html('账号或密码不正确!').show(200).hide(2000)
			}
		},
		error(err) {
			console.log(err.statusText)
		}
	})
})







