var currentNav = document.querySelector('#m_zhinengpeijian')
var layout01 = document.querySelectorAll('.layout01>div')
var layout02 = document.querySelectorAll('.layout02>div')

window.onload=function(){
    window.onscroll();
    if(sessionStorage.m_zhinengpeijian){
        currentNav.classList.add('navCurrent')
    }
    if(sessionStorage.userId){
        let userInfo = JSON.parse(sessionStorage.userInfo)
        document.querySelector('.menu_login').innerHTML = userInfo.nickname
    }  
}

// ==================通过判断滚动距离来展示加载样式


// 添加样式 的函数 
function addClass(obj){
    obj.classList.add('animation')
}

// 通过“offsetTop”来连续获取节点到文档顶部的距离并更新，直到节点再没有父级为止
function getTop(obj) {
    var h = 0;
    while (obj) {
        h += obj.offsetTop+20;
        obj = obj.offsetParent;
    }
    return h;
}
// 滚动实时计算所到区域计算“节点到顶部距离”与“滚动条滚动距离”的大小，当“滚动条滚动距离”大于“节点到顶部距离”时开始创建一个img（（1）的函数）
window.onscroll = function () {
    var t = document.documentElement.clientHeight + (document.body.scrollTop || document.documentElement.scrollTop);
    for (var i = 0; i < layout01.length; i++) {
        if (getTop(layout01[i]) < t) {
            setTimeout('addClass(layout01[' + i + '])', 500)
        }
    }
    for (var i = 0; i < layout02.length; i++) {
        if (getTop(layout02[i]) < t) {
            setTimeout('addClass(layout02[' + i + '])', 500)
        }
    }
}