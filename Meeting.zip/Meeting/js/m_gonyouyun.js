var currentNav = document.querySelector('#m_gonyouyun')
window.onload = function () {
    if (sessionStorage.m_gonyouyun) {
        currentNav.classList.add('navCurrent')
    }
    if(sessionStorage.userId){
        let userInfo = JSON.parse(sessionStorage.userInfo)
        document.querySelector('.menu_login').innerHTML = userInfo.nickname
    }  
}

var sceneNav = document.querySelectorAll('.sceneNav>li')
var sceneTxt = document.querySelectorAll('.sceneTxt>li')
var main_scene = document.querySelector('.main_scene')

for (var i = 0; i < sceneNav.length; i++) {
    sceneNav[i].addEventListener('click', function (event) {
        let index = Number(this.dataset.sceneindex)
        switch (index) {
            case 0:
                main_scene.style.backgroundImage = "url('../public/img/bg_situation_enterprise.png')";
                break;
            case 1:
                main_scene.style.backgroundImage = "url('../public/img/bg_situation_education.png')";
                break;
            case 2:
                main_scene.style.backgroundImage = "url('../public/img/bg_situation_enterprise1.png')";
                break;
            case 3:
                main_scene.style.backgroundImage = "url('../public/img/bg_situation_enterprise2.png')";
                break;
        }
        for (var i = 0; i < sceneNav.length; i++) {
            sceneNav[i].classList.remove('sceneNavCurrent')
            sceneTxt[i].classList.remove('sceneTxtCurrent')
        }
        sceneNav[index].classList.add('sceneNavCurrent')
        sceneTxt[index].classList.add('sceneTxtCurrent')
    }, false)
}