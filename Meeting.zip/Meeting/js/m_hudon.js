var currentNav = document.querySelector('#m_hudon')
window.onload=function(){
    if(sessionStorage.m_hudon){
        currentNav.classList.add('m_hudon_current')
    }
    if(sessionStorage.userId){
        let userInfo = JSON.parse(sessionStorage.userInfo)
        document.querySelector('.menu_login').innerHTML = userInfo.nickname
    }  
}