var currentNav = document.querySelector('#m_guanfang')
window.onload=function(){
    if(sessionStorage.m_guanfang){
        currentNav.classList.add('navCurrent')
    }
    if(sessionStorage.userId){
        let userInfo = JSON.parse(sessionStorage.userInfo)
        document.querySelector('.menu_login').innerHTML = userInfo.nickname
    }  
}